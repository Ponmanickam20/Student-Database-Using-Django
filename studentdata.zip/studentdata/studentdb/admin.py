from django.contrib import admin
from .models import Student
# Register your models here.

class studentAdmin(admin.ModelAdmin):
    lst=['reg_no','name','department','image']

admin.site.register(Student,studentAdmin)
