from django.shortcuts import render,redirect
from .forms import addForm
from .models import Student

# Create your views here.
def home(request):

    return render(request,'studentdb/home.html')


def display_students(request):
    students=Student.objects.all()

    return render(request,'studentdb/display_students.html',{'students':students})

def add(request):
    form=addForm()

    if request.method=='POST':
        form=addForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/add')
            

    return render(request,'studentdb/add_student.html',context={'form':form})


def search_student(request):
    if request.method == 'POST':
        reg_id = request.POST.get('reg_id')
        student = Student.objects.filter(reg_id=reg_id).first()
        if student:
            return render(request, 'studentdb/get_student.html', {'student': student})
        
    return render(request, 'studentdb/search_student.html')

def delete(request,id):
    student=Student.objects.get(id=id)

    student.delete()
    return redirect('/view_students')

def update(request,id):
    student=Student.objects.get(id=id)
    if request.method=='POST':

        form=addForm(request.POST,instance=student)
        if form.is_valid():
            form.save()
            return redirect('/view_students')

    return render(request,'studentdb/update_student.html',{'student':student})



